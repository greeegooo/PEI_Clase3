"use strict";
exports.__esModule = true;
var Compra = /** @class */ (function () {
    function Compra() {
    }
    return Compra;
}());
exports.Compra = Compra;
