"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DescuentoA = /** @class */ (function () {
    function DescuentoA() {
    }
    return DescuentoA;
}());
exports.DescuentoA = DescuentoA;
var DescuentoB = /** @class */ (function () {
    function DescuentoB() {
    }
    return DescuentoB;
}());
exports.DescuentoB = DescuentoB;
var DescuentoC = /** @class */ (function () {
    function DescuentoC() {
    }
    return DescuentoC;
}());
exports.DescuentoC = DescuentoC;
