export interface Descuento {}

export class DescuentoA implements Descuento {}

export class DescuentoB implements Descuento {}

export class DescuentoC implements Descuento {}
